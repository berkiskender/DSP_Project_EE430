The main script is "Encoder_main_script.m".

The code is adapted from EPFL's DSP course in Coursera: https://www.coursera.org/learn/dsp
The original code is written in Python. This version is a line-by-line adaptation to MATLAB.

Some parts may have been poorly adapted.
So, please do --not-- take this MATLAB code as a good code writing practice.

The code is tested in some recent versions of MATLAB.