% function x = quantization(sample, sf, ba, QCa, QCb)

