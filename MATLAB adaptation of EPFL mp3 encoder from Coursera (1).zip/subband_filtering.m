% function s = subband_filtering(x,h)

