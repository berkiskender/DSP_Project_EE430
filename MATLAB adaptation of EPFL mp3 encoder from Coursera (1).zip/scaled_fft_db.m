% function X = scaled_fft_db(x)
